import { Inclusion } from './inclusion';

describe('Inclusion', () => {
  it('should create an instance', () => {
    expect(new Inclusion()).toBeTruthy();
  });
});
