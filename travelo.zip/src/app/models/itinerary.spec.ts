import { Itinerary } from './itinerary';

describe('Itinerary', () => {
  it('should create an instance', () => {
    expect(new Itinerary()).toBeTruthy();
  });
});
