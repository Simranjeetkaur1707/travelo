export class User {
    userid:number;
    name:String;
    email:String;
    phone:String;
    password:String;
    address:{};
    payment_accounts:[];
}
