export class Itinerary {
    id : number ;
    packageid : number ;
    day : number ;
    highlight1 : string ;
    highlight2 : string ;
    description : string ;    
}
