import { Tour } from './tour';

describe('Tour', () => {
  it('should create an instance', () => {
    expect(new Tour()).toBeTruthy();
  });
});
