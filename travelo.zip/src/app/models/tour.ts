export class Tour {
    tourid:number;
    name:string;
    title:string;
    summary:string;
    description:string;
    international:boolean; 
    isactive:boolean; 
    featured:boolean;
    image:string;
}
