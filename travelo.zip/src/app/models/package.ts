export class Package{
    packageid : number;
    tourid : number;
    category : string;
    inclusion: string;
    title : string;
    cost : number;
    duration : string;
    summary : string;
    description : string;
    isactive : boolean;
    featured : boolean;
    images:string[];
}
