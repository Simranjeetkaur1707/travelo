export class Inclusion {
    inclusionid : number;
    name : string;  
}
