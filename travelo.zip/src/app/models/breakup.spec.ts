import { Breakup } from './breakup';

describe('Breakup', () => {
  it('should create an instance', () => {
    expect(new Breakup()).toBeTruthy();
  });
});
