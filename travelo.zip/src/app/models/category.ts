export class Category {
    categoryid : number;
    name : string;  
}
