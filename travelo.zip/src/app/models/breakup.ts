export class Breakup {
  breakupid : number ;
  packageid : number ;
  arrivehotelid : number ;
  departhotelid : number ;
  location: string ;
  days : number;
  orderid : number
}

