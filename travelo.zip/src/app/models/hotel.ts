export class Hotel {
    hotelid : number ;
    name : string ;
    place : string ;
    city : string ;
    state : string ;
    description : string ;
    rating : number ;
    image : string ;
    isactive :boolean;    
}

